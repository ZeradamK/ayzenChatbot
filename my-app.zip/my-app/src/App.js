import logo from './logo.svg';
import './App.css';
import Header from "./Components/Header/Header";
import LandingPage from "./Components/LandingPage/LandingPage";
import PromptSection from "./Components/PromptSection/PromptSection";
import {useEffect, useState} from "react";
import promptsData from '../src/Components/PromptSection/prompts.json';
import AboutSection from "./Components/AboutSection/AboutSection";
import Footer from "./Components/Footer/Footer";
import BaseFooter from "./Components/BaseFooter/BaseFooter";

function App() {
    const [isDarkMode, setIsDarkMode] = useState(false);

    const toggleTheme = () => {
        setIsDarkMode(!isDarkMode);
    };
    useEffect(() => {
        if (isDarkMode) {
            document.body.classList.add("dark-mode");
        } else {
            document.body.classList.remove("dark-mode");
        }
    }, [isDarkMode]);
      return (
        <div className={isDarkMode ? "dark-mode" : "light-mode"}>
            <div className={"bg-section"}>
                <section className={"section-bg1"}/>
                <section className={"section-bg2"}/>
                <section className={"section-bg3"}/>
                <section className={"section-bg4"}/>
            </div>
            <Header className={"header z-30"} toggleTheme={toggleTheme} />
            <LandingPage className={"z-30"}/>
            <PromptSection prompts={promptsData.prompts}/>
            <AboutSection toggleTheme={toggleTheme}/>
            <Footer/>
            <BaseFooter/>
        </div>
  );
}

export default App;
